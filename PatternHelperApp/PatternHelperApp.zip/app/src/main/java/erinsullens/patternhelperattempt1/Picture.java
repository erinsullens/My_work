package erinsullens.patternhelperattempt1;

import android.graphics.Bitmap;

/**
 * Created by erinsullens on 5/31/16.
 */
public class Picture {
    String name;
    Bitmap photo;


    public Picture(String name, Bitmap photo){
        this.name = name;
        this.photo = photo;
    }




}
