public class Step {
    int rowOnGrid;
    char[] harnessPattern;
    int harness;

    public Step(int row, char[] har, int harnessNumber){
        rowOnGrid = row;
        harnessPattern = har;
        harness = harnessNumber;
    }



}
