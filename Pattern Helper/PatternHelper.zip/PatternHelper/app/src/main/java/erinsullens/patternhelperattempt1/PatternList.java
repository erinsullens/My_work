package erinsullens.patternhelperattempt1;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

import android.app.Activity;
import android.content.Context;

/**
 * Created by erinsullens on 4/26/16.
 */
public class PatternList extends Activity {

    Pattern[] patterns = new Pattern[20];
    public int patternListIterator = 0;


    public void PatternListConstructor() {
        //make sure that patterns.txt is created
        FileInputStream fileInputStream=null;
        FileOutputStream fileOutputStream= null;

        try {
            new FileOutputStream("patterns.txt", true).close();
            String filler = "";
            fileOutputStream = openFileOutput("patterns.txt", Context.MODE_APPEND);
            fileOutputStream.write(filler.getBytes());
            fileOutputStream.flush();


        }catch(FileNotFoundException e) {
            //TODO Auto-generated catch block
            e.printStackTrace();

        }catch(IOException e){
            //TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally{
            try{
                if(fileOutputStream!= null) {
                    fileOutputStream.close();
                }
            }catch(IOException e){
                //TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        //Now read from patterns.txt
        try {
            String line = null;
            new FileInputStream("patterns.txt").close();
            fileInputStream = openFileInput("patterns.txt");
            InputStreamReader inStreamReaderObject = new InputStreamReader(fileInputStream);
            BufferedReader br = new BufferedReader((Reader) inStreamReaderObject);
            while(br.readLine() !=null){
                line = br.readLine();
                String[] result = line.split(" ");
                String name = result[0];
                String[] patternSteps = new String[result.length-1];
                for(int i = 0; i<result.length-1; i++){
                    patternSteps[i] = result[i+1];
                }
                patterns[patternListIterator] = new Pattern(name, patternSteps);
                System.out.println("Size of pattern: "+ patternSteps.length);
                for(int i =0; i< patternSteps.length; i++) {
                    System.out.println("PatternSteps: "+ patternSteps[i]);
                }
                patternListIterator++;
            }

        }catch(FileNotFoundException e){
            //TODO Auto-generated catch block
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
        String[] sample1 = {"1","2","3","4"};
        patterns[patternListIterator] = new Pattern("Sample", sample1);
    }

    public void addPattern(Pattern pattern){
        patterns[patternListIterator] = pattern;
        patternListIterator++;
    }



}