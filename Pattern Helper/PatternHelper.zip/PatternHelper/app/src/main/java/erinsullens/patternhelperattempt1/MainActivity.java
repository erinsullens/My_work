package erinsullens.patternhelperattempt1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        populateListView();
        registerClickCallback();
        setupButton();
    }

    private void populateListView(){
        PatternList patterns = new PatternList();
        patterns.PatternListConstructor();
        //NEED TO CHANGE TO FOR LOOP
        String[] list = {patterns.patterns[0].patternName};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.layout, list);
        ListView L = (ListView) findViewById(R.id.ListViewMain);
        L.setAdapter(adapter);

    }
    private void setupButton(){
        Button addButton = (Button)findViewById(R.id.addButton);

        View.OnClickListener myListener = new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent startNewActivity = new Intent(MainActivity.this, AddPattern.class);
                startActivity(startNewActivity);
            }
        };
        addButton.setOnClickListener(myListener);
    }


    final static int ADD_ITEM_INTENT = 1; // use to signify result of adding item



    private void registerClickCallback(){

        ListView L = (ListView) findViewById(R.id.ListViewMain);
        L.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> paret, View viewClicked, int position, long id){
                TextView textView = (TextView) viewClicked;
                PatternList patternList = new PatternList();
                patternList.PatternListConstructor();
               // System.out.println("First element in patternList: " + patternList.patterns[1].patternName);
                ArrayList<String> patternElements = new ArrayList<String>();
                for(int i = 0; i< patternList.patterns.length; i++) {
                    if (patternList.patterns[i] != null && patternList.patterns[i].patternName == textView.getText().toString()) {
                        for(int j = 0; j< patternList.patterns[i].patternList.length; j++){
                            patternElements.add(j, patternList.patterns[i].patternList[j]);
                        }
                    }
                }
                for(int i = 0; i< patternElements.size(); i++){
                    System.out.println(patternElements.get(i));
                }
                Intent startNewActivity = new Intent(MainActivity.this, ShowPattern.class);
                startNewActivity.putStringArrayListExtra("p", patternElements);
                startActivity(startNewActivity);
            }
        });
    }




}
